/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RecipeApp;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Ingredients class is used to gather information regarding specific objects  
 * of the ingredient 
 * Method addingIngredients creates an object Ingredients with user input 
 * as well as adds calorie amount to total calories for the recipe.
 * @author andre
 */
public class Ingredients {
    private String ingredient = "";
    private float cups = 0;
    private double caloriesPerCup = 0.0;
    private double totalIngredientCalories = 0.0;
    
    
    // Mutators
    /**
     * Sets the ingredient name
     * @param recipe ingredient name
     */
    public void setIngredientName(String recipe){
        this.ingredient = recipe;
        
    }
    /**
     * Assign cups 
     * @param cups number of cups
     */
    public void setCups(float cups){
        this.cups = cups;
    }
    /**
     * Assign caloriesPerCup
     * @param calories 
     */
    public void setCaloriesPerCup(double calories){
        this.caloriesPerCup = calories;
    }
   /**
    * Assign calories
    */
    public void setTotalCalories(){
        this.totalIngredientCalories = caloriesPerCup * cups;
    }
    
    // Accessors
    /**
     * Return ingredient name.
     * @return ingredientName
     */
    public String getIngredientName(){
        return ingredient;
    }
    /**
     * Return number of cups.
     * @return cups
     */
    public float getCups(){
        return cups;
    }
    /**
     * Return calorie count.
     * @return caloriesPerCup
     */
    public double getCaloriesPer(){
        return caloriesPerCup;
    }
    /**
     * Return entire amount of calories.
     * @return totalIngredientCalories
     */
    public double getTotalIngredientCalories(){
        return totalIngredientCalories;
    }
    /**
     * Takes user input to create an ingredient object to use in other classes.
     * @param ingredientName
     * @return Ingredient object
     */
    public Ingredients addingIngredient(String ingredientName){
        Scanner scnr = new Scanner(System.in);
        
        // gather user inputs      
        ingredient = ingredientName;      
        
        System.out.println("How many cups do you have? ");
        if(scnr.hasNextFloat()){
            float amountOfCups = scnr.nextFloat();
            setCups(amountOfCups);
        }
        // Be sure the value is above 0 or minimum cup limit
        if(cups > 0){
            
            // Gather calories per cup
            System.out.println("How many calories per cup? ");
            if(scnr.hasNextDouble()){
                caloriesPerCup = scnr.nextDouble();
                setCaloriesPerCup(caloriesPerCup);
            }
            setTotalCalories();
        }
        else {
          System.out.println("Not enough cups were entered. Please try again..");
          
          
        }
        
        return new Ingredients();
    }     
    
}
