/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RecipeApp;
import java.util.ArrayList;

/**
 * RecipeBox is a class that stores an array list of recipes created
 * the class inherits the recipe information from the Recipe class and stores
 * that within an ArrayList. 
 * We have methods to create a new recipe and add it to the list of recipes, 
 * as well as print methods to reveal the recipe book to the user and the recipe 
 * ingredients inside.
 * 
 * @author Andre Rawls 
 */
public class RecipeBox extends Recipe{
    
    private ArrayList<Recipe> listOfRecipes = new ArrayList();
    boolean cont = true;
    // Constructors
    /**
     * Initial constructor.
     */
    public RecipeBox(){
        this.listOfRecipes = new ArrayList();
    }
    /**
     * pre-initialized recipeBox
     * @param recipes a recipe already created by the user or default input.
     */
    public RecipeBox(ArrayList recipes){
        this.listOfRecipes = recipes;
    }
    
    // Accessors and Mutators
    /**
     * Method to quit inner program while loops.
     */
    public void quit(){
        this.cont = false;
    }
    /**
     * Returns boolean
     * @return boolean
     */
    public boolean End(){
        return cont;
    }
    /**
     * Return list of recipes 
     * @return listOfRecipes
     */
    public ArrayList getListOfRecipes(){
        return listOfRecipes;
    }
    /**
     * Set list of recipes from a recipe class
     * @param recipes 
     */
    public void setListOfRecipes(Recipe recipes){
        listOfRecipes.add(recipes);
    }
    /**
     * Prints the specific details of a user given recipe choice.
     * @param recipe the recipe the user is searching for
     */
    public void printAllRecipeDetails(String recipe){
        
        boolean recipeInside = true;
        
        for(int j = 0; j <= (listOfRecipes.size()-1); ++j){
            
            if(listOfRecipes.get(j).getRecipeName().equalsIgnoreCase(recipe.toLowerCase())){
                System.out.println(recipe + " Found!\n");
                listOfRecipes.get(j).printRecipe();
                recipeInside = false;
            }
        }
        if(recipeInside){
            System.out.println("There is no recipe by that name. Please try again!");
        }
        
        
    }
    /**
     * Object to print all recipe names within the recipeBox.
     */
    public void printAllRecipeNames(){
        
        System.out.print("| ");
        for(int i = 0; i <= (listOfRecipes.size() -1); ++i){
            String recipeName = listOfRecipes.get(i).getRecipeName();
            System.out.print(recipeName + " | ");
        }
        System.out.println();
    }
    /**
     * Creation of a new recipe for the recipe box. Calls on the recipe class to 
     * create recipe with ingredients and caloric information.
     */
    public void addNewRecipe(){
        Recipe recipe = new Recipe();
        recipe.addRecipe();
        listOfRecipes.add(recipe);
        
    }
    
}
