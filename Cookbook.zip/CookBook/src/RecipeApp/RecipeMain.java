/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RecipeApp;
import java.util.Scanner;
import java.util.ArrayList;

/**
     * RecipeMain is the main function of the recipeApp
     * Designed to offer choices created from the inherited recipeBox class 
     * and create or return the recipes stored within. 
     * The main class takes user input and inherits class methods from 
     * RecipeBox/Recipe/Ingredients
     * 
     * 
     * 
     * @author Andre Rawls
     */
public class RecipeMain {
    
    /**
     * The main function that users will interact with to create new recipes, view all 
     * recipes, or view specific recipes.
     * @param args 
     */
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        RecipeBox recipe1 = new RecipeBox();
                
        do{
            
            System.out.println("\n==============================================================================\n");
            
            System.out.println("Choice: A) Create a new Recipe B) Print Recipe Names C) Print Recipe Details Q) Quit ");
            String choice = scnr.nextLine().toUpperCase();
            switch(choice){

                case "A":
                    /**
                     * Creates recipe1 with user inputs.
                     */
                    System.out.println("====================== Welcome to Recipe Creation! ==================\n");
                    recipe1.addNewRecipe();                   
                    break;
                case "B":
                    /**
                     * Prints all recipe names held in recipeBook array list. 
                     */
                    System.out.println("================ Printing All Recipe Names ================"); 
                    if(recipe1.getListOfRecipes().size() > 0){
                        recipe1.printAllRecipeNames();
                    }
                    else{System.out.println("This Recipe Book is empty!");}
                    
                    
                    break;
                case "C":
                    /**
                     * Prints all recipe names for user to choose from for complete recipe details. 
                     */
                    System.out.println("============= Entering Detailed Recipe ===============\n");
                    String recipe = "";
                    recipe1.printAllRecipeNames();
                    System.out.print("Choose a Recipe: ");
                    // IF statement whether the choice is in the array or not. Is not case sensitive.
                    if(scnr.hasNext()){
                        recipe = scnr.nextLine();
                        recipe1.printAllRecipeDetails(recipe);
                        //Clear Scanner
                        System.out.println("Press Enter to continue..");
                        scnr.nextLine();
                    }
                    else{
                        //If typo or given recipe not in the array, returns invalid option.
                        recipe1.printAllRecipeDetails("");
                        // Clear Scanner
                        scnr.nextLine();
                    }
                    
                    break;
                case "Q":
                    System.out.println("\nGoodbye\n");
                    recipe1.quit();
                    break;
                default:
                    System.out.println("Not a viable option...");

            }
        } while(recipe1.End());
        
    }
    
}
