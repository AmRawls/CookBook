/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RecipeApp;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *Recipe class is used to create the recipes given user input.
 * It is designed to take input parameters such as recipe name and the ingredients
 * and returns a recipe object which contains recipe name, ArrayList of ingredients,
 * serving size, and total calories.
 * @author andre
 */
public class Recipe extends Ingredients {
    private String recipeName = "";
    private int servings = 0;
    private ArrayList<String> recipeIngredients = new ArrayList();
    private double totalCalories = 0;
    
    /**
     * Recipe Constructors for initial class.
     */
    public Recipe(){
        this.recipeName = "";
        this.servings = 0;
        this.recipeIngredients = new ArrayList();
        this.totalCalories = 0;
    }

    /**
     * Recipe constructor with already initialized values.
     * @param recipe Recipe name
     * @param serving Serving Size
     * @param ingredients List of ingredients
     * @param calories Number of total calories
     */
    public Recipe(String recipe, int serving, ArrayList ingredients, double calories){
        this.recipeName = recipe;
        this.servings = serving;
        this.recipeIngredients = ingredients;
        this.totalCalories = calories;
    }

    // Mutators 
    /**
     * Assign recipeName.
     * @param name Recipe Name
     */
    public void setRecipeName(String name){
        this.recipeName = name;
    }

    /**
     * Assign servings.
     * @param serving Serving size.
     */
    public void setServings(int serving){
        this.servings = serving;
    }

    /**
     * Adds given ingredient to the IngredientsList
     * @param ingredient name of ingredient
     */
    public void setIngredientsList(String ingredient){
        this.recipeIngredients.add(ingredient);
    }

    /**
     * Adds the ingredient's caloric information to the totalRecipeCalories
     * @param calories caloric information for the individual ingredient.
     */
    public void setRecipeCalories(double calories){
        this.totalCalories += calories;
    } 

    // Accesssors 
    /**
     * Returns the recipe name.
     * @return recipeName
     */
    public String getRecipeName(){
        return recipeName;
    }

    /**
     * Returns the serving size.
     * @return Serving size.
     */
    public int getServings(){
        return servings;
    }

    /**
     * Returns list of ingredients.
     * @return IngredientsList
     */
    public ArrayList getIngredientsLists(){
        return recipeIngredients;
    }

    /**
     * Total recipe calories.
     * @return totalRecipeCalories
     */
    public double getRecipeCalories(){
        return totalCalories;
    }

    /**
     * Method that will create a recipe with user inputs and assign values to
     * internal variables. Creates a returnable object to be used for the recipe box.
     * @return Recipe object to be used in the RecipeBox
     */
    public Recipe addRecipe(){
        Scanner scnr = new Scanner(System.in);
        try {
            boolean cont = true;

            // User inputs for recipe information
            System.out.println("What is the name of the recipe? ");
            if(scnr.hasNextLine()){
                setRecipeName(scnr.nextLine().toUpperCase());
            }
            System.out.println("How many Servings? ");
            if(scnr.hasNextInt()){
                setServings(scnr.nextInt());
            }
            scnr.nextLine();
            //While loop to collect ingredients from user 
            System.out.println("What are the ingredients? Enter end when done.");
            if(scnr.hasNextLine()){
                String ingredient = scnr.nextLine();
                do {  
                    if(!ingredient.equalsIgnoreCase("end")){
                        this.addingIngredient(ingredient);
                        setRecipeCalories(this.getTotalIngredientCalories());
                        //this.addToCabinet(ingredient);
                        setIngredientsList(ingredient);
                        System.out.println("Next Ingredient? Enter 'end' if done. "); // output causes double up
                        if(scnr.hasNextLine()){
                            ingredient = scnr.nextLine();
                        }
                        else{
                            System.out.println("Invalid ingredient");
                            cont = false;
                        }                       
                    }
                    else{
                        cont = false;
                    }
                } while(cont);
            }
            else{
                System.out.println("Invalid ingredient!");
            }
            totalCalories = (getRecipeCalories() * servings);
        } catch(Exception e){
            System.out.println("Illegal entry");
            recipeName = "";
        }
        return new Recipe(recipeName, servings, recipeIngredients, totalCalories); 
    }
    
    /**
     * Object to print the recipe.
     */
    public void printRecipe(){
        System.out.println("------ Printing Recipe -------\n");
        System.out.println("Recipe Name: " + getRecipeName());
        System.out.println("Servings: " + getServings());
        System.out.println("Ingredients: " + recipeIngredients.size() +"\n" +getIngredientsLists());
        System.out.println("Total Calories: " + (int)(getRecipeCalories()));
        System.out.println();
    }
    
    
    
    
    
}
